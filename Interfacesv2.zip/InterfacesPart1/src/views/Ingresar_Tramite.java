/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package views;

import java.awt.Color;
import java.awt.Font;
import static java.time.LocalDateTime.now;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import logica.*;
import logica.LogicaTramite.*;
import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;


/**
 *
 * @author Maritza
 */
public class Ingresar_Tramite extends javax.swing.JFrame {

    private static final String PRIO_PLACEHOLDER = "ingresar prioridad";
    private static final String NOM_PLACEHOLDER = "ingresar nombre y apellido";
    private static final String DNI_PLACEHOLDER = "ingresar dni";
    private static final String TEL_PLACEHOLDER = "ingresar telefono";
    private static final String CORR_PLACEHOLDER = "ingresar correo";
    private static final String ASUN_PLACEHOLDER = "ingresar asunto";
    private static final String DOC_PLACEHOLDER = "ingresar documento";
    private Administrador admin = new Administrador("pepe", "1232");
    private Gestion_Tramite GT = new Gestion_Tramite();
    
    
    public Ingresar_Tramite() {
        initComponents();
        
        AddPlaceHolder(prioridad, PRIO_PLACEHOLDER);
        AddPlaceHolder(nomyape, NOM_PLACEHOLDER);
        AddPlaceHolder(dni, DNI_PLACEHOLDER);
        AddPlaceHolder(tel, TEL_PLACEHOLDER);
        AddPlaceHolder(core, CORR_PLACEHOLDER);
        AddPlaceHolder(asunto, ASUN_PLACEHOLDER);
        AddPlaceHolder(doc, DOC_PLACEHOLDER);
    }
    
    public void AddPlaceHolder(JTextField textField, String placeholder)
        {
            Font font = textField.getFont();
            font = font.deriveFont(Font.ITALIC);
            textField.setFont(font);
            textField.setForeground(Color.gray);
            textField.setText(placeholder);
            
        }
    
      public void RemovePlaceHolder(JTextField textField)
        {
            Font font = textField.getFont();
            font = font.deriveFont(Font.PLAIN|Font.BOLD);
            textField.setFont(font);
            textField.setForeground(Color.black);  
            
        }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        prioridad = new javax.swing.JTextField();
        nomyape = new javax.swing.JTextField();
        dni = new javax.swing.JTextField();
        tel = new javax.swing.JTextField();
        core = new javax.swing.JTextField();
        asunto = new javax.swing.JTextField();
        doc = new javax.swing.JTextField();
        Rellenar = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        jLabel1.setText("Ingresar Tramite");

        jLabel2.setFont(new java.awt.Font("Segoe UI Semibold", 1, 14)); // NOI18N
        jLabel2.setText("Prioridad:");

        jLabel3.setFont(new java.awt.Font("Segoe UI Semibold", 1, 14)); // NOI18N
        jLabel3.setText("Nombre y Apellido:");

        jLabel4.setFont(new java.awt.Font("Segoe UI Semibold", 1, 14)); // NOI18N
        jLabel4.setText("DNI:");

        jLabel5.setFont(new java.awt.Font("Segoe UI Semibold", 1, 14)); // NOI18N
        jLabel5.setText("Telefono:");

        jLabel6.setFont(new java.awt.Font("Segoe UI Semibold", 1, 14)); // NOI18N
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("Correo:");
        jLabel6.setToolTipText("");

        jLabel7.setFont(new java.awt.Font("Segoe UI Semibold", 1, 14)); // NOI18N
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setText("Asunto:");
        jLabel7.setToolTipText("");

        jLabel8.setFont(new java.awt.Font("Segoe UI Semibold", 1, 14)); // NOI18N
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setText("Documentos:");
        jLabel8.setToolTipText("");

        prioridad.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                prioridadFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                prioridadFocusLost(evt);
            }
        });
        prioridad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                prioridadActionPerformed(evt);
            }
        });

        nomyape.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                nomyapeFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                nomyapeFocusLost(evt);
            }
        });

        dni.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                dniFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                dniFocusLost(evt);
            }
        });

        tel.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                telFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                telFocusLost(evt);
            }
        });

        core.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                coreFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                coreFocusLost(evt);
            }
        });

        asunto.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                asuntoFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                asuntoFocusLost(evt);
            }
        });

        doc.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                docFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                docFocusLost(evt);
            }
        });

        Rellenar.setText("Rellenar");
        Rellenar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RellenarActionPerformed(evt);
            }
        });

        jButton2.setText("Cancelar");

        jButton3.setText("Vaciar campos");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(67, 67, 67)
                                    .addComponent(jLabel2))
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(39, 39, 39)
                                    .addComponent(jLabel3)))
                            .addGap(22, 22, 22)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(prioridad)
                                .addComponent(nomyape, javax.swing.GroupLayout.DEFAULT_SIZE, 174, Short.MAX_VALUE)))
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                    .addComponent(jLabel4)
                                    .addGap(66, 66, 66))
                                .addGroup(layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel8, javax.swing.GroupLayout.Alignment.TRAILING))
                                    .addGap(22, 22, 22)))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(dni)
                                .addComponent(tel)
                                .addComponent(core)
                                .addComponent(asunto)
                                .addComponent(doc, javax.swing.GroupLayout.DEFAULT_SIZE, 174, Short.MAX_VALUE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(132, 132, 132)
                        .addComponent(jLabel1)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 39, Short.MAX_VALUE)
                .addComponent(jButton3)
                .addGap(18, 18, 18)
                .addComponent(jButton2)
                .addGap(18, 18, 18)
                .addComponent(Rellenar)
                .addGap(72, 72, 72))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(jLabel1)
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(prioridad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(nomyape, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(dni, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(tel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(core, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(asunto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(doc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 31, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Rellenar)
                    .addComponent(jButton2)
                    .addComponent(jButton3))
                .addGap(17, 17, 17))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void RellenarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RellenarActionPerformed
       String Prioridad = prioridad.getText();
       String NombreyApellido = nomyape.getText();
       String DNI = dni.getText();
       String telefono = tel.getText();
       String correo = core.getText();
       String Asunto = asunto.getText();
       String Documento = doc.getText();
        
       if(!Prioridad.equals(PRIO_PLACEHOLDER) && !Prioridad.isEmpty() &&
               !NombreyApellido.equals(NOM_PLACEHOLDER) && !NombreyApellido.isEmpty() &&
               !DNI.equals(DNI_PLACEHOLDER) && !DNI.isEmpty() && 
               !telefono.equals(TEL_PLACEHOLDER) && !telefono.isEmpty() && 
               !correo.equals(CORR_PLACEHOLDER) && !correo.isEmpty() &&
               !Asunto.equals(ASUN_PLACEHOLDER) && !Asunto.isEmpty() &&
               !Documento.equals(DOC_PLACEHOLDER) && !Documento.isEmpty()
               )
       {
           Usuario usu1 = new Usuario("71959397", "Pep Guardiola", "934999712", "pepitoalcachofa@gmail.com");
           Usuario usu2 = new Usuario("83941832", "Ricardo Moran", "999 975 222", "pepitoalcachofa@gmail.com");
           Usuario usu3 = new Usuario("71959397", "Pep Guardiola", "934999712", "pepitoalcachofa@gmail.com");
           
            
           
            JOptionPane.showMessageDialog(null, "Se registro todo correctamente");
            DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
            String formattedDateTime = LocalDateTime.now().format(formato);
            JOptionPane.showMessageDialog(null, "Fecha del dia: " + formattedDateTime);
       }
       else
       {
           JOptionPane.showMessageDialog(null, "Falta rellenar un apartado");
       }
           

       
    }//GEN-LAST:event_RellenarActionPerformed

    private void prioridadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_prioridadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_prioridadActionPerformed

    private void prioridadFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_prioridadFocusGained
        if(prioridad.getText().equals(PRIO_PLACEHOLDER))
     {
         prioridad.setText("");
         RemovePlaceHolder(prioridad);
     }
    }//GEN-LAST:event_prioridadFocusGained

    private void nomyapeFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_nomyapeFocusGained
        if(nomyape.getText().equals(NOM_PLACEHOLDER))
     {
         nomyape.setText("");
         RemovePlaceHolder(nomyape);
     }
    }//GEN-LAST:event_nomyapeFocusGained

    private void dniFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_dniFocusGained
      if(dni.getText().equals(DNI_PLACEHOLDER))
     {
         dni.setText("");
         RemovePlaceHolder(dni);
     }
    }//GEN-LAST:event_dniFocusGained

    private void telFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_telFocusGained
      if(tel.getText().equals(TEL_PLACEHOLDER));
     {
         tel.setText("");
         RemovePlaceHolder(tel);
     }
    }//GEN-LAST:event_telFocusGained

    private void coreFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_coreFocusGained
       if(core.getText().equals(CORR_PLACEHOLDER));
     {
         core.setText("");
         RemovePlaceHolder(core);
     }
    }//GEN-LAST:event_coreFocusGained

    private void asuntoFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_asuntoFocusGained
      if(asunto.getText().equals(ASUN_PLACEHOLDER));
     {
         asunto.setText("");
         RemovePlaceHolder(asunto);
     }
    }//GEN-LAST:event_asuntoFocusGained

    private void docFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_docFocusGained
       if(doc.getText().equals(DOC_PLACEHOLDER));
     {
         doc.setText("");
         RemovePlaceHolder(doc);
     }
    }//GEN-LAST:event_docFocusGained

    private void prioridadFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_prioridadFocusLost
        if(prioridad.getText().isEmpty())
        {
            AddPlaceHolder(prioridad, PRIO_PLACEHOLDER);
        }
    }//GEN-LAST:event_prioridadFocusLost

    private void nomyapeFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_nomyapeFocusLost
        if(nomyape.getText().isEmpty())
        {
            AddPlaceHolder(nomyape, NOM_PLACEHOLDER);
        }
    }//GEN-LAST:event_nomyapeFocusLost

    private void dniFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_dniFocusLost
       if(dni.getText().isEmpty())
        {
            AddPlaceHolder(dni, DNI_PLACEHOLDER);
        }
    }//GEN-LAST:event_dniFocusLost

    private void telFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_telFocusLost
       if(tel.getText().isEmpty())
        {
            AddPlaceHolder(tel, TEL_PLACEHOLDER);
        }
    }//GEN-LAST:event_telFocusLost

    private void coreFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_coreFocusLost
        if(core.getText().isEmpty())
        {
            AddPlaceHolder(core, CORR_PLACEHOLDER);
        }
    }//GEN-LAST:event_coreFocusLost

    private void asuntoFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_asuntoFocusLost
        if(asunto.getText().isEmpty())
        {
            AddPlaceHolder(asunto, ASUN_PLACEHOLDER);
        }
    }//GEN-LAST:event_asuntoFocusLost

    private void docFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_docFocusLost
       if(doc.getText().isEmpty())
        {
            AddPlaceHolder(doc, DOC_PLACEHOLDER);
        }
    }//GEN-LAST:event_docFocusLost

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Ingresar_Tramite.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Ingresar_Tramite.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Ingresar_Tramite.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Ingresar_Tramite.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Ingresar_Tramite().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Rellenar;
    private javax.swing.JTextField asunto;
    private javax.swing.JTextField core;
    private javax.swing.JTextField dni;
    private javax.swing.JTextField doc;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JTextField nomyape;
    private javax.swing.JTextField prioridad;
    private javax.swing.JTextField tel;
    // End of variables declaration//GEN-END:variables
}
